//This node publishes random confidence levels of motors, pendulum, ballast, controllers and navigators

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "UNEXMIN_self_awareness/conf_message.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "conf_publisher_node");
  ros::NodeHandle n;

	//This is topic where the information is published
  ros::Publisher conf_pub = n.advertise<UNEXMIN_self_awareness::conf_message>("UNEXMIN_confidence_levels", 1);
	UNEXMIN_self_awareness::conf_message msg;

	ros::Rate loop_rate(0.1);	//New values are published every 10 seconds

	while (ros::ok())
  {
		
		msg.T1 						= ((float) rand()) / (float) RAND_MAX;
		msg.T2 						= ((float) rand()) / (float) RAND_MAX;
		msg.T3 						= ((float) rand()) / (float) RAND_MAX;
		msg.T4 						= ((float) rand()) / (float) RAND_MAX;
		msg.T5 						= ((float) rand()) / (float) RAND_MAX;
		msg.T6 						= ((float) rand()) / (float) RAND_MAX;
		msg.T7 						= ((float) rand()) / (float) RAND_MAX;
		msg.T8 						= ((float) rand()) / (float) RAND_MAX;
		msg.Ballast 			= ((float) rand()) / (float) RAND_MAX;
		msg.Pendulum 			= ((float) rand()) / (float) RAND_MAX;
		msg.Controller_1 	= ((float) rand()) / (float) RAND_MAX;
		msg.Controller_2 	= ((float) rand()) / (float) RAND_MAX;
		msg.Controller_b 	= ((float) rand()) / (float) RAND_MAX;
		msg.Controller_p 	= ((float) rand()) / (float) RAND_MAX;
		msg.Navigator_1 	= ((float) rand()) / (float) RAND_MAX;
		msg.Navigator_2 	= ((float) rand()) / (float) RAND_MAX;
		
		conf_pub.publish(msg);

    ros::spinOnce();
    loop_rate.sleep();
  }
  return 0;
}
