//This node is subscribed to "UNEXMIN_confidence_levels" and is in charge of asking the Java Class and publishing the results

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "UNEXMIN_self_awareness/conf_message.h"
#include "UNEXMIN_self_awareness/metacontrol_message.h"
#include <sstream>
#include <iostream>
#include <jni.h>
#include <assert.h>

using namespace std;
bool new_query = false;
float states[] = {0.02, 0.3, 0.9, 0.6, 0.3, 0.6, 0.56, 0.23, 0.67, 1.0, 0.9, 0.8, 0.7, 1.0, 0.1, 0.6};

//In this function confidence levels are brought together in the "states" array to be sent to Java class
void conf_Callback(const UNEXMIN_self_awareness::conf_message& msg)
{
	states[0]  = msg.T1;							states[1] = msg.T2;
	states[2]  = msg.T3;							states[3] = msg.T4;
	states[4]  = msg.T5;							states[5] = msg.T6;
	states[6]  = msg.T7;							states[7] = msg.T8;
	states[8]  = msg.Ballast;					states[9] = msg.Pendulum;
	states[10] = msg.Controller_1;		states[11] = msg.Controller_2;
	states[12] = msg.Controller_b;		states[13] = msg.Controller_p;
	states[14] = msg.Navigator_1;			states[15] = msg.Navigator_2;

  new_query = true; //This boolean variable allows to call the Java class in the "main" function
}

//This function decodes the information provided by the Java class
UNEXMIN_self_awareness::metacontrol_message decode(int code_1, int code_2, int code_3)
{
	UNEXMIN_self_awareness::metacontrol_message msg_metacontrol;

	switch (code_1){
		case 1:		//role_t1_t3
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T3";
			break;
		case 2:		//role_t2_t4
			msg_metacontrol.Motor_A = "T2";
			msg_metacontrol.Motor_B = "T4";
			break;
		case 3:		//role_t1_t4
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T4";
			break;
		case 4:		//role_t2_t3
			msg_metacontrol.Motor_A = "T2";
			msg_metacontrol.Motor_B = "T3";
			break;
		case 5:		//role_t5_t7
			msg_metacontrol.Motor_A = "T5";
			msg_metacontrol.Motor_B = "T7";
			break;
		case 6:		//role_t6_t8
			msg_metacontrol.Motor_A = "T6";
			msg_metacontrol.Motor_B = "T8";
			break;
		case 7:		//role_t1_t2_t3
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T2";
			msg_metacontrol.Motor_C = "T3";
			break;
		case 8:		//role_t1_t2_t4
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T2";
			msg_metacontrol.Motor_C = "T4";
			break;
		case 9:		//role_t1_t3_t4
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T3";
			msg_metacontrol.Motor_C = "T4";
			break;
		case 10:	//role_t2_t3_t4
			msg_metacontrol.Motor_A = "T2";
			msg_metacontrol.Motor_B = "T3";
			msg_metacontrol.Motor_C = "T4";
			break;
		case 11:	//role_t5_t6_t7
			msg_metacontrol.Motor_A = "T5";
			msg_metacontrol.Motor_B = "T6";
			msg_metacontrol.Motor_C = "T7";
			break;
		case 12:	//role_t5_t6_t8
			msg_metacontrol.Motor_A = "T5";
			msg_metacontrol.Motor_B = "T6";
			msg_metacontrol.Motor_C = "T8";
			break;
		case 13:	//role_t5_t7_t8
			msg_metacontrol.Motor_A = "T5";
			msg_metacontrol.Motor_B = "T7";
			msg_metacontrol.Motor_C = "T8";
			break;
		case 14:	//role_t6_t7_t8
			msg_metacontrol.Motor_A = "T6";
			msg_metacontrol.Motor_B = "T7";
			msg_metacontrol.Motor_C = "T8";
			break;
		case 15:	//role_t1_t2_t3_t4
			msg_metacontrol.Motor_A = "T1";
			msg_metacontrol.Motor_B = "T2";
			msg_metacontrol.Motor_C = "T3";
			msg_metacontrol.Motor_D = "T4";
			break;
		case 16:	//role_t5_t6_t7_t8
			msg_metacontrol.Motor_A = "T5";
			msg_metacontrol.Motor_B = "T6";
			msg_metacontrol.Motor_C = "T7";
			msg_metacontrol.Motor_D = "T8";
			break;
		case 17:	//role_ballast
			msg_metacontrol.Ballast = "Ballast";
			break;
		case 18:	//role_pendulum
			msg_metacontrol.Pendulum = "Pendulum";
			break;
		default:
			break;
	}

	switch (code_2){
		case 1:		//role_controller_1
			msg_metacontrol.Controller = "Controller_1";
			break;
		case 2:		//role_controller_2
			msg_metacontrol.Controller = "Controller_2";
			break;
		case 3:		//role_controller_b
			msg_metacontrol.Controller = "Controller_b";
			break;
		case 4:		//role_controller_p
			msg_metacontrol.Controller = "Controller_p";
			break;
		default:
			break;
	}

	switch (code_3){
		case 1:		//role_navigator_1
			msg_metacontrol.Navigator = "Navigator_1";
			break;
		case 2:		//role_navigator_2
			msg_metacontrol.Navigator = "Navigator_2";
			break;
		default:
			break;
	}
	
	return msg_metacontrol;
}

JNIEnv* initialize_jni(JavaVM *jvm)
{
	JNIEnv *env;
	//==================== prepare loading of Java VM ============================

	JavaVMInitArgs vm_args;                        // Initialization arguments
	JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
	options[0].optionString = (char*) "-Djava.class.path=/home/parallels/catkin_ws/src/UNEXMIN_self_awareness/src/owl_reasoner/target/owl_reasoner-1.2.2-jar-with-dependencies.jar";   // where to find java .class

	vm_args.version = JNI_VERSION_1_8;             // minimum Java version
	vm_args.nOptions = 1;                          // number of options
	vm_args.options = options;
	vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail

	//================= load and initialize Java VM and JNI interface ===============

	jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
	delete options;    // we then no longer need the initialisation options. 

	//========================= analyse errors if any  ==============================
	// if process interuped before error is returned, it's because jvm.dll can't be 
	// found, i.e.  its directory is not in the PATH. 

	if(rc != JNI_OK) {
		if(rc == JNI_EVERSION)
			cerr << "FATAL ERROR: JVM is oudated and doesn't meet requirements" << endl;
		else if(rc == JNI_ENOMEM)
			cerr << "FATAL ERROR: not enough memory for JVM" << endl;
		else if(rc == JNI_EINVAL)
			cerr << "FATAL ERROR: invalid ragument for launching JVM" << endl;
		else if(rc == JNI_EEXIST)
			cerr << "FATAL ERROR: the process can only launch one JVM an not more" << endl;
		else
			cerr << "FATAL ERROR:  could not create the JVM instance (error code " << rc << ")" << endl;
		cin.get();
		exit(EXIT_FAILURE);
	}

	cout << "JVM load succeeded. \nVersion ";

	return env;
}

jmethodID get_reasoner_method(JNIEnv *env, jobject &obj)
{
	jmethodID reasonMethodId;
	jclass cls2 = env->FindClass("cz/makub/Metacontrol");  // try to find the class 

	if(cls2 == NULL) {
		cerr << "ERROR: class not found !";
	}
	else {                                  // if class found, continue
		cout << "Class Metacontrol found" << endl;
		//Instantiate the object
		jmethodID constr = env->GetMethodID(cls2, "<init>", "()V");
		obj = env->NewObject(cls2, constr);
		reasonMethodId = env->GetMethodID(cls2, "query_java", "([F)[I");  // find method
		
		assert(reasonMethodId != NULL);

	}
	return reasonMethodId;
}



int main(int argc, char **argv)
{
  
  ros::init(argc, argv, "query_node");
  ros::NodeHandle n;

	//Topic where confidence levels are published
	ros::Subscriber sub = n.subscribe("UNEXMIN_confidence_levels", 1, conf_Callback);

	//Topics where the solutions for each objective is published
	ros::Publisher ob_front_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_front", 1);
	ros::Publisher ob_back_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_back", 1);
	ros::Publisher ob_yaw_right_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_yaw_right", 1);
	ros::Publisher ob_yaw_left_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_yaw_left", 1);
	ros::Publisher ob_up_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_up", 1);
	ros::Publisher ob_down_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_down", 1);
	ros::Publisher ob_pitch_pub = n.advertise<UNEXMIN_self_awareness::metacontrol_message>("UNEXMIN_ob_pitch", 1);
	
  ros::Rate loop_rate(1);

	JavaVM *jvm;
	JNIEnv *env;
	env = initialize_jni(jvm);
	jobject queryEngine;
	jmethodID query_java_MethodId = get_reasoner_method(env, queryEngine); //Find the method of interest in the class


  while (ros::ok())
  {
		if (new_query == true){
			
			cout << endl << endl;
			cout << "There have been a change in confidence levels" << endl;
			cout << "We are asking the reasoner" << endl;

			jfloatArray javaStates = env->NewFloatArray(22); 	//Declaration of container (array) to be sent to Java. Size = 22-1
			env->SetFloatArrayRegion(javaStates,0,22, states); //[0, 22) range of indices of "javaStates" to be filled with "states" array

			//Java method is called
			jintArray jdecision = (jintArray) env->CallObjectMethod(queryEngine, query_java_MethodId, javaStates);
			jint *decisionArray = env->GetIntArrayElements(jdecision, NULL);
			
			//All messages are prepared and decoded
			UNEXMIN_self_awareness::metacontrol_message msg_front, msg_back, msg_yaw_right, msg_yaw_left, msg_up, msg_down, msg_pitch;
			msg_front 		= decode(decisionArray[0], decisionArray[1], decisionArray[2]);			msg_front.Objective ="Ob_front";
			msg_back  		= decode(decisionArray[3], decisionArray[4], decisionArray[5]);			msg_back.Objective ="Ob_back";
			msg_yaw_right = decode(decisionArray[6], decisionArray[7], decisionArray[8]);			msg_yaw_right.Objective ="Ob_yaw_right";
			msg_yaw_left  = decode(decisionArray[9], decisionArray[10], decisionArray[11]);		msg_yaw_left.Objective ="Ob_yaw_left";
			msg_up    		= decode(decisionArray[12], decisionArray[13], decisionArray[14]);	msg_up.Objective ="Ob_up";
			msg_down  		= decode(decisionArray[15], decisionArray[16], decisionArray[17]);	msg_down.Objective ="Ob_down";
			msg_pitch  		= decode(decisionArray[18], decisionArray[19], decisionArray[20]);	msg_pitch.Objective ="Ob_pitch";
			
			//The messages are published
			ob_front_pub.publish(msg_front);
			ob_back_pub.publish(msg_back);
			ob_yaw_right_pub.publish(msg_yaw_right);
			ob_yaw_left_pub.publish(msg_yaw_left);
			ob_up_pub.publish(msg_up);
			ob_down_pub.publish(msg_down);
			ob_pitch_pub.publish(msg_pitch);

			//There is no new query until new confidence levels are published
			new_query = false;

		}

    ros::spinOnce();
    loop_rate.sleep();
  }


  return 0;
}
