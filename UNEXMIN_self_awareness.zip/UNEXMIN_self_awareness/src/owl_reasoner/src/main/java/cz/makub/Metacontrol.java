package cz.makub;

import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.dlsyntax.renderer.DLSyntaxObjectRenderer;
import org.semanticweb.owlapi.formats.PrefixDocumentFormat;
import org.semanticweb.owlapi.io.OWLObjectRenderer;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class Metacontrol {

	private static File file = new File("/home/parallels/catkin_ws/src/UNEXMIN_self_awareness/src/UNEXMIN_metacontrol.owl");
    private static OWLObjectRenderer renderer = new DLSyntaxObjectRenderer();
    private static OWLNamedIndividual fg_ctrl, fg_nav;
    private static int[] code = new int[21];
    private static float max_ctrl, max_nav;
    
    public int[] query_java(float[] states) throws OWLOntologyCreationException {
    	
    	//Ontology and reasoner is prepared
    	OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = manager.loadOntologyFromOntologyDocument(file); //Ontology loaded from variable "file"
        OWLReasonerFactory reasonerFactory = PelletReasonerFactory.getInstance();
        OWLReasoner reasoner = reasonerFactory.createReasoner(ontology, new SimpleConfiguration()); //Pellet reasoner is created
        OWLDataFactory factory = manager.getOWLDataFactory();
        PrefixDocumentFormat pm = manager.getOntologyFormat(ontology).asPrefixOWLOntologyFormat();	//A prefix is set, so the names of the ontology elements are much shorter
        pm.setDefaultPrefix("http://www.semanticweb.org/gonza/ontologies/2018/6/untitled-ontology-50#");
       
        //Some classes and properties needed from the ontology
        OWLClass Class_Role = factory.getOWLClass(":Role", pm);
        OWLClass Class_Motor = factory.getOWLClass(":CC_Motor", pm);
        OWLClass Class_Ballast = factory.getOWLClass(":CC_Ballast", pm);
        OWLClass Class_Pendulum = factory.getOWLClass(":CC_Pendulum", pm);
        OWLClass Class_Navigator = factory.getOWLClass(":CC_Navigator", pm);
        OWLClass Class_Controller = factory.getOWLClass(":CC_Controller", pm);
        
        OWLClass Function_Design = factory.getOWLClass(":Function_Design", pm);
        OWLClass FD_Control = factory.getOWLClass(":FD_Control", pm);
        OWLClass FD_Navigation = factory.getOWLClass(":FD_Navigation", pm);
        OWLClass FD_Planification = factory.getOWLClass(":FD_Planification", pm);
        
        OWLDataProperty confidence_level_component = factory.getOWLDataProperty(":confidence_level_component", pm);
        OWLDataProperty confidence_level_role = factory.getOWLDataProperty(":confidence_level_role", pm);
        OWLDataProperty confidence_level_FD = factory.getOWLDataProperty(":confidence_level_FD", pm);

        OWLObjectProperty comply_with = factory.getOWLObjectProperty(":comply_with", pm);
        OWLObjectProperty has_role_A = factory.getOWLObjectProperty(":has_role_A", pm);
        OWLObjectProperty has_role_B = factory.getOWLObjectProperty(":has_role_B", pm);
        OWLObjectProperty has_role_C = factory.getOWLObjectProperty(":has_role_C", pm);
        
        //All role confidence levels are deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Role, confidence_level_role);
        
        //All function_grounding confidence levels are deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Function_Design, confidence_level_FD);
        
        //All motor confidence levels are deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Motor, confidence_level_component);
        
        //Ballast confidence level is deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Ballast, confidence_level_component);
        
        //Pendulum confidence level is deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Pendulum, confidence_level_component);
        
        //All controller confidence levels are deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Controller, confidence_level_component);
        
        //All navigator confidence levels are deleted
        ontology = delete_axioms(manager, ontology, reasoner, factory, Class_Navigator, confidence_level_component);
        
        //Motor confidence levels are updated
        ontology = add_axioms(manager, ontology, reasoner, factory, pm, Class_Motor, confidence_level_component, states); //motors

        //Ballast confidence level is updated
        ontology = add_axioms(manager, ontology, reasoner, factory, pm, Class_Ballast, confidence_level_component, states); //ballast
        
        //Pendulum confidence level is updated
        ontology = add_axioms(manager, ontology, reasoner, factory, pm, Class_Pendulum, confidence_level_component, states); //pendulum
      
        //Controller confidence levels are updated
        ontology = add_axioms(manager, ontology, reasoner, factory, pm, Class_Controller, confidence_level_component, states); //is controllers

        //Navigator confidence levels are updated
        ontology = add_axioms(manager, ontology, reasoner, factory, pm, Class_Navigator, confidence_level_component, states); //navigators

	    //Ontology is updated
	    reasoner.flush();
	    try {
			manager.saveOntology(ontology);
		} catch (OWLOntologyStorageException e) {
			e.printStackTrace();
		}
	    
	    //The objectives which are going to be ask about 
        OWLNamedIndividual ob_front = factory.getOWLNamedIndividual(":o_control_front", pm);
        OWLNamedIndividual ob_back = factory.getOWLNamedIndividual(":o_control_back", pm);
        OWLNamedIndividual ob_yaw_right = factory.getOWLNamedIndividual(":o_control_yaw_right", pm);
        OWLNamedIndividual ob_yaw_left = factory.getOWLNamedIndividual(":o_control_yaw_left", pm);
        OWLNamedIndividual ob_up = factory.getOWLNamedIndividual(":o_control_up", pm);
        OWLNamedIndividual ob_down = factory.getOWLNamedIndividual(":o_control_down", pm);
        OWLNamedIndividual ob_pitch = factory.getOWLNamedIndividual(":o_control_pitch", pm);
        
        //Objective front
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_front, 0);
    	System.out.println("\nBest FG Control (front) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (front) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
	    //Objective back
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_back, 3);
    	System.out.println("\nBest FG Control (back) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (back) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
	    //Objective yaw right
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_yaw_right, 6);
        System.out.println("\nBest FG Control (yaw_right) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (yaw_right) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
        //Objective yaw left
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_yaw_left, 9);
        System.out.println("\nBest FG Control (yaw_left) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (yaw_left) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
	    //Objective up
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_up, 12);
        System.out.println("\nBest FG Control (up) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (up) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
	    //Objective down
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_down, 15);
        System.out.println("\nBest FG Control (down) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (down) " + renderer.render(fg_nav) + " with confidence_level " + max_nav);
        
        //Objective pitch
        solution(reasoner, factory, pm, FD_Control, FD_Navigation, confidence_level_FD, comply_with, has_role_A, has_role_B, ob_pitch, 18);
        System.out.println("\nBest FG Control (pitch) " + renderer.render(fg_ctrl) + " with confidence_level " + max_ctrl);
        System.out.println("Best FG Navigation (pitch) " + renderer.render(fg_nav) + " with confidence_level " + max_nav + "\n");

        //FGs Planification
        for (OWLNamedIndividual fg_planner : reasoner.getInstances(FD_Planification, false).getFlattened()) {
        	for (OWLLiteral conf : reasoner.getDataPropertyValues(fg_planner, confidence_level_FD)) {
        		String value_str = conf.getLiteral();
	            float conf_planner = Float.parseFloat(value_str);
	            System.out.println("FG Planification " + renderer.render(fg_planner) + " with confidence_level " + conf_planner);
            }//Close for
        }//Close for
        
        return code;
        
    }//Close function "query_java"
    
    
    private static OWLOntology delete_axioms(OWLOntologyManager manager, OWLOntology ontology, OWLReasoner reasoner, OWLDataFactory factory, OWLClass cclass, OWLDataProperty confidence) { 	
	    //All instances of the class have their confidence level removed (motors, ballast, pendulum, controllers and navigators)
    	for (OWLNamedIndividual ind : reasoner.getInstances(cclass, false).getFlattened()) {
	        for (OWLLiteral conf : reasoner.getDataPropertyValues(ind, confidence)) {
	            float value_flt = Float.parseFloat(conf.getLiteral());
	            OWLDataPropertyAssertionAxiom axiom = factory.getOWLDataPropertyAssertionAxiom(confidence, ind, value_flt);
	            manager.removeAxiom(ontology, axiom);
	        }//Close for
	    }//Close for
    	
	    return ontology;
	    
    }//Close function "detele_axioms"
    
    private static OWLOntology add_axioms(OWLOntologyManager manager, OWLOntology ontology, OWLReasoner reasoner, OWLDataFactory factory, PrefixDocumentFormat pm, OWLClass cclass, OWLDataProperty confidence, float states[]) { 	
	    
    	//All instances of the class have their confidence level updated (motors, ballast, pendulum, controllers and navigators)
    	float aux = 0;	
    	for (OWLNamedIndividual ind : reasoner.getInstances(cclass, false).getFlattened()) {
 
			if (ind == factory.getOWLNamedIndividual(":t1", pm))					aux = states[0];
		    else if (ind == factory.getOWLNamedIndividual(":t2", pm)) 				aux = states[1];
		    else if (ind == factory.getOWLNamedIndividual(":t3", pm)) 				aux = states[2];
		    else if (ind == factory.getOWLNamedIndividual(":t4", pm)) 				aux = states[3];
		    else if (ind == factory.getOWLNamedIndividual(":t5", pm)) 				aux = states[4];
		    else if (ind == factory.getOWLNamedIndividual(":t6", pm)) 				aux = states[5];
		    else if (ind == factory.getOWLNamedIndividual(":t7", pm)) 				aux = states[6];
		    else if (ind == factory.getOWLNamedIndividual(":t8", pm)) 				aux = states[7];
        	else if (ind == factory.getOWLNamedIndividual(":ballast", pm))			aux = states[8];
        	else if (ind == factory.getOWLNamedIndividual(":pendulum", pm))			aux = states[9];
        	else if (ind == factory.getOWLNamedIndividual(":controller_1", pm))		aux = states[10];
		    else if (ind == factory.getOWLNamedIndividual(":controller_2", pm)) 	aux = states[11];
		    else if (ind == factory.getOWLNamedIndividual(":controller_b", pm)) 	aux = states[12];
		    else if (ind == factory.getOWLNamedIndividual(":controller_p", pm)) 	aux = states[13];
        	else if (ind == factory.getOWLNamedIndividual(":navigator_1", pm))		aux = states[14];
    		else if (ind == factory.getOWLNamedIndividual(":navigator_2", pm)) 		aux = states[15];		
    		
		    String aux_1 = String.format("%.111f",aux);
		    String aux_2 = aux_1.replace(",", ".");
		    float aux_3 = Float.parseFloat(aux_2);            
		    OWLDataPropertyAssertionAxiom axiom = factory.getOWLDataPropertyAssertionAxiom(confidence, ind, aux_3); 
		    manager.applyChange(new AddAxiom(ontology, axiom));
	    }//Close for
    	
	    return ontology;
	    
	}//Close function "add_axioms"

    
    private static void solution(OWLReasoner reasoner, OWLDataFactory factory, PrefixDocumentFormat pm, OWLClass FD_Control, OWLClass FD_Navigation, OWLDataProperty confidence, OWLObjectProperty comply_with, OWLObjectProperty has_role_A, OWLObjectProperty has_role_B, OWLNamedIndividual objective, int i) {
    	
    	fg_ctrl = get_best_fg(reasoner, factory, pm, FD_Control, confidence, comply_with, objective); //The best fg control is obtained
        fg_nav  = get_best_nav(reasoner, factory, pm, FD_Navigation, confidence, has_role_A, fg_ctrl, has_role_B); //The best fg nav is obtained
        code[i]   = get_code(reasoner, factory, pm, fg_ctrl, has_role_A);	//Code for rol_motor, ballast or pendulum
        code[i+1] = get_code(reasoner, factory, pm, fg_ctrl, has_role_B);	//Code for controller
    	code[i+2] = get_code(reasoner, factory, pm, fg_nav, has_role_B);	//Code for navigator
    	
    }//Close function "solution" 
    
    
    private static OWLNamedIndividual get_best_nav(OWLReasoner reasoner, OWLDataFactory factory, PrefixDocumentFormat pm, OWLClass FD_Navigation, OWLDataProperty confidence, OWLObjectProperty has_role_A, OWLNamedIndividual fg_ctrl, OWLObjectProperty has_role_B) {
    	
    	for (OWLNamedIndividual controller : reasoner.getObjectPropertyValues(fg_ctrl, has_role_B).getFlattened()) {
    		return get_best_fg(reasoner, factory, pm, FD_Navigation, confidence, has_role_A, controller);
	    }//Close for
    	
	    return null;
	    
    }//Close function "get_best_nav"
    
    
    private static OWLNamedIndividual get_best_fg(OWLReasoner reasoner, OWLDataFactory factory, PrefixDocumentFormat pm, OWLClass FD_Class, OWLDataProperty confidence, OWLObjectProperty property, OWLNamedIndividual comparative) {
    	
        ArrayList<Float> conf_level_array = new ArrayList<Float>();
        
        for (OWLNamedIndividual fg : reasoner.getInstances(FD_Class, false).getFlattened()) {
	        for (OWLLiteral conf : reasoner.getDataPropertyValues(fg, confidence)) {
	        	for (OWLNamedIndividual ind : reasoner.getObjectPropertyValues(fg, property).getFlattened()) {
	                if (ind == comparative) {
	                	String value_str = conf.getLiteral();
			            float value_flt = Float.parseFloat(value_str);         
			            conf_level_array.add(value_flt);
	                }//Close if
	            }//Close for
	        }//Close for
        }//Close for
        
        Float maximum = Collections.max(conf_level_array);
    	
		if (FD_Class == factory.getOWLClass(":FD_Control", pm))
        	max_ctrl = maximum;
        else
        	max_nav = maximum;
        
    	for (OWLNamedIndividual fg : reasoner.getInstances(FD_Class, false).getFlattened()) {
        	for (OWLLiteral conf : reasoner.getDataPropertyValues(fg, confidence)) {
		        for (OWLNamedIndividual ind : reasoner.getObjectPropertyValues(fg, property).getFlattened()) {
		    		if (ind == comparative) {
		    			String value_str = conf.getLiteral();
			            float value_flt = Float.parseFloat(value_str);
			            if (value_flt == maximum) {
			            	return fg;
			            }//Close if
		            }//Close if
		        }//Close for
        	}//Close for
        }//Close for
    	
		return null;
		
    }//Close function "get_best_fg"
        
    private static int get_code(OWLReasoner reasoner, OWLDataFactory factory, PrefixDocumentFormat pm, OWLNamedIndividual fg, OWLObjectProperty has_role) {
    	
    	for (OWLNamedIndividual ind : reasoner.getObjectPropertyValues(fg, has_role).getFlattened()) {  	    
	    	if (ind == factory.getOWLNamedIndividual(":role_t1_t3", pm))				return 1;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t2_t4", pm))			return 2;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t1_t4", pm))			return 3;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t2_t3", pm))			return 4;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t5_t7", pm))			return 5;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t6_t8", pm))			return 6;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t1_t2_t3", pm))		return 7;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t1_t2_t4", pm))		return 8;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t1_t3_t4", pm))		return 9;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t2_t3_t4", pm))		return 10;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t5_t6_t7", pm))		return 11;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t5_t6_t8", pm))		return 12;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t5_t7_t8", pm))		return 13;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t6_t7_t8", pm))		return 14;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t1_t2_t3_t4", pm))		return 15;
	    	else if (ind == factory.getOWLNamedIndividual(":role_t5_t6_t7_t8", pm))		return 16;
	    	else if (ind == factory.getOWLNamedIndividual(":role_ballast", pm))			return 17;
	    	else if (ind == factory.getOWLNamedIndividual(":role_pendulum", pm))		return 18;
	    	else if (ind == factory.getOWLNamedIndividual(":role_controller_1", pm)) 	return 1;
	    	else if (ind == factory.getOWLNamedIndividual(":role_controller_2", pm)) 	return 2;
	    	else if (ind == factory.getOWLNamedIndividual(":role_controller_b", pm)) 	return 3;
	    	else if (ind == factory.getOWLNamedIndividual(":role_controller_p", pm)) 	return 4;
	    	else if (ind == factory.getOWLNamedIndividual(":role_navigator_1", pm))		return 1;
	    	else if (ind == factory.getOWLNamedIndividual(":role_navigator_2", pm))		return 2;
    	}//Close for
    	
    	return 0;
    	
    }//Close function "get_code"
	
}//Close Java Class


  
